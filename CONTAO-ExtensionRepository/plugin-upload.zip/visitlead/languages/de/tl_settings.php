<?php	
	
$GLOBALS['TL_LANG']['tl_settings']['visitlead_settings'] = 'Visitlead Einstellungen';
$GLOBALS['TL_LANG']['tl_settings']['visitlead_id'] = array('Visitlead ID', 'Geben Sie Ihre Visitlead ID ein, der JavaScript Code wird dann automatisch im Quellcode eingefügt.');
