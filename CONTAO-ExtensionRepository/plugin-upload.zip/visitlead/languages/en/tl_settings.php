<?php	
	
$GLOBALS['TL_LANG']['tl_settings']['visitlead_settings'] = 'Visitlead Settings';
$GLOBALS['TL_LANG']['tl_settings']['visitlead_id'] = array('Visitlead ID', 'Please put in your Vistalead ID, the necessary script will be added to your Site by our module.');
